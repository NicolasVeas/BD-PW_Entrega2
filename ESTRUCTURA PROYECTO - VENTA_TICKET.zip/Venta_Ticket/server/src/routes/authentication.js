const express = require('express');
const router = express.Router();
const conn = require('../database');
const passport = require('passport');


// router.get('/signin', (req,res) => {
//     res.render('signin.ejs');
// });
router.get('/signup', (req,res) =>{
    res.render('signup.ejs');
});

router.get('/login', (req,res) =>{
    res.render('login.ejs');
});

router.post('/login',passport.authenticate('local',{
    successRedirect: "/evento",
    failureRedirect: "/login"
}));

// router.get('/correcto',  (req,res,next)=>{
//     if(req.isAuthenticated()) return next();
    
//     res.redirect('/login');
// },(req,res) =>{
//     res.render('evento.ejs');
// });



module.exports = router;