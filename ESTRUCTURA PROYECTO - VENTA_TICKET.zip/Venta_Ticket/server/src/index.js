const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const passport = require('passport');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const morgan = require('morgan');
const validator = require('express-validator');
const MySQLStore = require('express-mysql-session')(session);
const flash = require('connect-flash');
const PassportLocal = require('passport-local').Strategy;
// Intializations
const app = express();
const conn = require('./database');
//archivos estaticos
app.use('/img',express.static(path.join(__dirname, '/public/img')));
app.use('/css',express.static(path.join(__dirname, '/public/css')));

// Configuración
app.set('port',  process.env.PORT || 3000);
app.set('views', path.join(__dirname,'views'));
app.set('view engine','ejs');      



// Middleware (funciones que se procesan antes de llegar a rutas)
app.use(express.json()); //Transfomar a formato JSON
app.use(bodyParser.urlencoded({extended: false}));
app.use(flash());
app.use(cookieParser('el secreto'));
app.use(session({
     secret: 'el secreto',
     resave: true, //la sesión se guardar cada vez
     saveUninitialized: true    //Si inicializamos y no le guardamos nada igual va a guardar
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new PassportLocal(function(username,password,done){ 
     console.log(username)// callback with email and password from our form
     conn.query("SELECT * FROM `usuario` WHERE `rut` = '"  + username + "'",function(err,rows){
          if (err)
               return done(err);
          if (!rows.length) {
               return done(null, false); 
          }    
     if (!( rows[0].password == password))
               return done(null, false); 
     
     return done(null, {id:rows[0].id_usuario});			
     
     });
     
}));
//Serialización, parar la información para identificar usuario en passport
passport.serializeUser(function(user,done){
     done(null,user.id);
});
//Deserializacion
passport.deserializeUser(function(id,done){
     done(null, {id:1, name: "Manuel"})
});

// Rutas (URL)
app.use(require('./routes/usuario'));
app.use(require('./routes/evento'));
app.use(require('./routes/ticket'));
app.use(require('./routes/venta'));
app.use(require('./routes/ticket_venta'));
app.use(require('./routes/authentication'));
app.use(require('./routes/etapa2'));

app.listen(app.get('port'), () => {
     console.log('Servidor en puerto ',app.get('port'))
});
