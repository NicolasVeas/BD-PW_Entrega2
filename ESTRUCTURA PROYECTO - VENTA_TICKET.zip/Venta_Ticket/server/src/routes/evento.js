const express = require('express');
const router = express.Router();

const conn = require('../database');

// router.get('/correcto', (req,res,next)=>{
//     if(req.isAuthenticated()) return next();
        
//         res.redirect('/login');
// },(req,res) =>{
//         res.render('evento.ejs');
// });
    
//evento vista de usuario
router.get('/usuario/evento', (req,res,next) => {
    if(req.isAuthenticated()) return next();

        res.redirect('/login');
},(req,res) =>{
    conn.query('Select * FROM evento', (err,resp,campos) => {
        res.render('home.ejs',{
            datos: resp
        });
    });
});

// mostrar todos los eventos
router.get('/evento', (req,res,next) => {
    if(req.isAuthenticated()) return next();

        res.redirect('/login');
},(req,res) =>{
    conn.query('Select * FROM evento', (err,resp,campos) => {
        res.render('evento.ejs',{
            datos: resp
        });
    });
});

//actualizar 1 evento
router.post('/actualizar/:id', (req, res) => {
    const { id } = req.params;
    const newCus = req.body;
    //console.log(req.body);
    conn.query('UPDATE evento SET ? where id_evento = ?', [newCus, id], (err, result) => {
        if(!err) {
            res.redirect('/evento');
        } else {
            console.log(err);
        }
    });
});

//ingresar un evento
router.post('/ingresar',(req, res) => {
    //console.log(req.body);
    const {nombre, fecha, hora, lugar, descripcion, categoria, capacidad} = req.body;
    conn.query('INSERT into evento SET? ',{
        nombre: nombre,
        fecha: fecha,
        hora: hora,
        lugar: lugar,
        descripcion: descripcion,
        categoria: categoria,
        capacidad: capacidad
    }, (err, result) => {
        if(!err) {
            res.redirect('/evento');
        } else {
            console.log(err);
        }
    });
});

//eliminar un evento
router.get('/eliminar/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('DELETE from evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){ 
            res.redirect('/evento')
        }else{
            console.log(err);
        }
    });
});

//seleccionar 1 evento
router.get('/actualizar/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('SELECT * FROM evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){ 
            //console.log(resp[0]);
            res.render('evento_edit.ejs',{
                datos: resp[0]
                
            });
        }else{
            console.log(err);
        }
    });
});



/*
router.get('/evento/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('Select * from evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

router.delete('/evento/:id',(req, res) => {
    const { id } = req.params;
    conn.query('DELETE FROM evento WHERE id_evento = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Evento borrado sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.put('/evento/:id',(req, res) => {
    const { id } = req.params;
    conn.query('UPDATE evento SET fecha="2020-10-18", hora="19:00:00", lugar="Plaza Vergara", nombre="Mega Ultra Ramada 18chera", categoria="especiales", imagen=null, capacidad=100 WHERE id_evento = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Evento modificado sin problemas...'});
        } else {
            console.log(err);
        }
    });
});*/
module.exports = router;