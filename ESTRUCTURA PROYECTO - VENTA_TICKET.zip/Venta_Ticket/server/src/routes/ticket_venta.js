
const express = require('express');
const router = express.Router();

const conn = require('../database');

router.post('/ticket_venta',(req, res) => {
    const { id } = req.params;
    conn.query('INSERT INTO ticket_venta(id_ticket,id_venta) values (25,2),(26,2),(27,2)', (err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'ticket_venta modificado sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

module.exports = router;
