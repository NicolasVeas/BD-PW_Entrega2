const express = require('express');
const router = express.Router();
const conn = require('../database');


//ADMINISTRADOR consulta la cantidad de dinero gastado en tickets un usuario en especifico
router.get('/tickets/especifico', (req,res) =>{
    const { id } = req.params;
    conn.query('SELECT SUM(precio), t.id_usuario FROM ticket as t INNER JOIN ticket_venta as tv  ON t.id_ticket = tv.id_ticket  WHERE t.id_usuario = ?', [id], (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//ADMINISTRADOR consulta las ganancias totales por cada categoria de evento que se han generado en este momento 
router.get('/evento/ganancia', (req,res) =>{
    
    conn.query('SELECT SUM(precio) as "Ganancia total", e.categoria FROM ticket as t INNER JOIN evento e ON t.id_evento = e.id_evento WHERE t.disponible = 0 group by categoria', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//ADMINISTRADOR consulta la cantidad de tickets disponibles segun la fecha de realizacion de los eventos 
router.get('/tickets/disponibles', (req,res) =>{
    
    conn.query('SELECT fecha, count(*) as tickets FROM ticket as t INNER JOIN evento e  ON t.id_evento=e.id_evento group by fecha', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//ADMINISTRADOR consulta la cantidad de tickets disponibles segun el nombre de cada evento
router.get('/evento/tickets/', (req,res) =>{
    
    conn.query('SELECT nombre, count(*) as tickets FROM ticket as t INNER JOIN evento e  ON t.id_evento=e.id_evento group by nombre', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//-- ADMINISTRADOR consulta la cantidad de tickets disponibles segun la categoria de cada evento
router.get('/tickets/categoria', (req,res) =>{
    
    conn.query('SELECT categoria, count(*) as tickets FROM ticket as t INNER JOIN evento e  ON t.id_evento=e.id_evento  group by categoria', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//-- ADMINISTRADOR consulta la cantidad de Tickets sin vender de cada eventos
router.get('/tickets/null', (req,res) =>{
    
    conn.query('SELECT count(*) as "Numero de Tickets sin vender", e.nombre FROM ticket as t INNER JOIN evento e ON t.id_evento = e.id_evento WHERE t.id_usuario is  null group by nombre', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//-- ADMINISTRADOR consulta la cantidad de tablas dentro de la base de tados 
router.get('/db/tables', (req,res) =>{
    
    conn.query('SELECT count(*) cantidad_tablas FROM information_schema.tables WHERE table_schema = "proyecto_ticket" ORDER BY table_name DESC', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//-- ADMINISTRADOR pide informacion sobre una columna en especifico de una trabla
router.get('/db/tables/information', (req,res) =>{
    
    conn.query('SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = "evento" AND table_schema = "proyecto_ticket" AND column_name LIKE "id_evento"', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

//-- ADMINISTRADOR consulta los usuarios hombres que han comprado ticket
router.get('/tickets/usuarios/hombres', (req,res) =>{
    
    conn.query('SELECT DISTINCT u.id_usuario FROM usuario u JOIN (SELECT id_usuario, id_ticket    FROM ticket )AS t ON u.id_usuario = t.id_usuario WHERE u.sexo = "M"; module.exports = router', (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});


/*las otras dos estan que faltan las coloque en routes/evento y routes/ticket que son:
--ADMINISTRADOR consulta los usuarios que han comprado ticket
-- Administrador puede visualizar la ventas y ticket con su información general
*/

module.exports = router;